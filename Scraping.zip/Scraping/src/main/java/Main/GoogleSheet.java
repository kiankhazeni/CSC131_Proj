package Main;

import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpResponseException;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.google.auth.http.HttpCredentialsAdapter;
import com.google.auth.oauth2.GoogleCredentials;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class GoogleSheetsWriter {

    private static final String APPLICATION_NAME = "Student Scraper";

    static Sheets createSheetsService(String keyPath) throws Exception {
        GoogleCredentials credentials = GoogleCredentials
                .fromStream(new FileInputStream(keyPath))
                .createScoped(Collections.singleton(SheetsScopes.SPREADSHEETS));

        return new Sheets.Builder(
                GoogleNetHttpTransport.newTrustedTransport(),
                GsonFactory.getDefaultInstance(),
                new HttpCredentialsAdapter(credentials)
        ).setApplicationName(APPLICATION_NAME).build();
    }

    static void appendRow(
            Sheets sheets,
            String spreadsheetId,
            String range,
            List<Object> row
    ) throws Exception {

        ValueRange body = new ValueRange()
                .setValues(Collections.singletonList(row));

        try {
            sheets.spreadsheets().values()
                    .append(spreadsheetId, range, body)
                    .setValueInputOption("RAW")
                    .setInsertDataOption("INSERT_ROWS")
                    .execute();
        } catch (HttpResponseException e) {
            System.out.println("Google Sheets error: " + e.getStatusCode());
            System.out.println("Google Sheets body: " + e.getContent());
            throw e;
        }
    }

    static List<String> getExistingEmails(
            Sheets sheets,
            String spreadsheetId,
            String range
    ) throws Exception {

        ValueRange response = sheets.spreadsheets().values()
                .get(spreadsheetId, range)
                .execute();

        List<List<Object>> values = response.getValues();
        List<String> emails = new ArrayList<>();

        if (values == null) {
            return emails;
        }

        for (int i = 1; i < values.size(); i++) {
            List<Object> row = values.get(i);
            if (!row.isEmpty()) {
                String email = row.get(0).toString().trim().toLowerCase();
                if (!email.isEmpty()) {
                    emails.add(email);
                }
            }
        }

        return emails;
    }
}